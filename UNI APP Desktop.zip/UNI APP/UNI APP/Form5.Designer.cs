﻿namespace UNI_APP
{
    partial class FormHomeHead
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormHomeHead));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PanelHead = new DevComponents.DotNetBar.Controls.SlidePanel();
            this.PanelLogo = new DevComponents.DotNetBar.Controls.SlidePanel();
            this.btnAddLesson = new DevComponents.DotNetBar.ButtonX();
            this.btnEditLesson = new DevComponents.DotNetBar.ButtonX();
            this.btnEditLessonStudent = new DevComponents.DotNetBar.ButtonX();
            this.btnReportCard = new DevComponents.DotNetBar.ButtonX();
            this.btnAddStudent = new DevComponents.DotNetBar.ButtonX();
            this.btnEditStudent = new DevComponents.DotNetBar.ButtonX();
            this.btnEditProfessor = new DevComponents.DotNetBar.ButtonX();
            this.btnAddProfessor = new DevComponents.DotNetBar.ButtonX();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.PanelHead.SuspendLayout();
            this.PanelLogo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-4, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1143, 723);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(188, 186);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // PanelHead
            // 
            this.PanelHead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.PanelHead.Controls.Add(this.btnAddProfessor);
            this.PanelHead.Controls.Add(this.btnEditProfessor);
            this.PanelHead.Controls.Add(this.btnEditStudent);
            this.PanelHead.Controls.Add(this.btnAddStudent);
            this.PanelHead.Controls.Add(this.btnReportCard);
            this.PanelHead.Controls.Add(this.btnEditLessonStudent);
            this.PanelHead.Controls.Add(this.btnEditLesson);
            this.PanelHead.Controls.Add(this.btnAddLesson);
            this.PanelHead.Controls.Add(this.PanelLogo);
            this.PanelHead.Dock = System.Windows.Forms.DockStyle.Right;
            this.PanelHead.Location = new System.Drawing.Point(954, 0);
            this.PanelHead.Name = "PanelHead";
            this.PanelHead.Size = new System.Drawing.Size(186, 703);
            this.PanelHead.TabIndex = 6;
            this.PanelHead.Text = "slidePanel1";
            this.PanelHead.UsesBlockingAnimation = false;
            // 
            // PanelLogo
            // 
            this.PanelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.PanelLogo.Controls.Add(this.pictureBox2);
            this.PanelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelLogo.Location = new System.Drawing.Point(0, 0);
            this.PanelLogo.Name = "PanelLogo";
            this.PanelLogo.Size = new System.Drawing.Size(186, 184);
            this.PanelLogo.TabIndex = 7;
            this.PanelLogo.UsesBlockingAnimation = false;
            // 
            // btnAddLesson
            // 
            this.btnAddLesson.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAddLesson.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnAddLesson.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddLesson.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnAddLesson.Location = new System.Drawing.Point(0, 184);
            this.btnAddLesson.Name = "btnAddLesson";
            this.btnAddLesson.Size = new System.Drawing.Size(186, 48);
            this.btnAddLesson.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnAddLesson.TabIndex = 10;
            this.btnAddLesson.Text = "افزودن درس جدید";
            // 
            // btnEditLesson
            // 
            this.btnEditLesson.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnEditLesson.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnEditLesson.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEditLesson.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnEditLesson.Location = new System.Drawing.Point(0, 232);
            this.btnEditLesson.Name = "btnEditLesson";
            this.btnEditLesson.Size = new System.Drawing.Size(186, 48);
            this.btnEditLesson.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnEditLesson.TabIndex = 11;
            this.btnEditLesson.Text = "ویرایش و حذف دروس اراعه شده";
            // 
            // btnEditLessonStudent
            // 
            this.btnEditLessonStudent.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnEditLessonStudent.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnEditLessonStudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEditLessonStudent.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnEditLessonStudent.Location = new System.Drawing.Point(0, 280);
            this.btnEditLessonStudent.Name = "btnEditLessonStudent";
            this.btnEditLessonStudent.Size = new System.Drawing.Size(186, 48);
            this.btnEditLessonStudent.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnEditLessonStudent.TabIndex = 12;
            this.btnEditLessonStudent.Text = "ویرایش دروس دانشجو";
            // 
            // btnReportCard
            // 
            this.btnReportCard.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnReportCard.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnReportCard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReportCard.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnReportCard.Location = new System.Drawing.Point(0, 328);
            this.btnReportCard.Name = "btnReportCard";
            this.btnReportCard.Size = new System.Drawing.Size(186, 48);
            this.btnReportCard.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnReportCard.TabIndex = 13;
            this.btnReportCard.Text = "کارنامه دانشجو";
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAddStudent.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnAddStudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddStudent.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnAddStudent.Location = new System.Drawing.Point(0, 376);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(186, 48);
            this.btnAddStudent.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnAddStudent.TabIndex = 14;
            this.btnAddStudent.Text = "افزودن دانشجو جدید";
            // 
            // btnEditStudent
            // 
            this.btnEditStudent.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnEditStudent.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnEditStudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEditStudent.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnEditStudent.Location = new System.Drawing.Point(0, 424);
            this.btnEditStudent.Name = "btnEditStudent";
            this.btnEditStudent.Size = new System.Drawing.Size(186, 48);
            this.btnEditStudent.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnEditStudent.TabIndex = 15;
            this.btnEditStudent.Text = "ویرایش و حذف دانشجویان";
            // 
            // btnEditProfessor
            // 
            this.btnEditProfessor.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnEditProfessor.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnEditProfessor.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEditProfessor.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnEditProfessor.Location = new System.Drawing.Point(0, 472);
            this.btnEditProfessor.Name = "btnEditProfessor";
            this.btnEditProfessor.Size = new System.Drawing.Size(186, 48);
            this.btnEditProfessor.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnEditProfessor.TabIndex = 16;
            this.btnEditProfessor.Text = "ویرایش اساتید";
            // 
            // btnAddProfessor
            // 
            this.btnAddProfessor.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAddProfessor.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnAddProfessor.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddProfessor.Font = new System.Drawing.Font("B Narm", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnAddProfessor.Location = new System.Drawing.Point(0, 520);
            this.btnAddProfessor.Name = "btnAddProfessor";
            this.btnAddProfessor.Size = new System.Drawing.Size(186, 48);
            this.btnAddProfessor.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnAddProfessor.TabIndex = 17;
            this.btnAddProfessor.Text = "افزودن استاد";
            this.btnAddProfessor.Click += new System.EventHandler(this.buttonX7_Click);
            // 
            // FormHomeHead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1140, 703);
            this.Controls.Add(this.PanelHead);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormHomeHead";
            this.Text = "صفحه اصلی مدیر گروه";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.PanelHead.ResumeLayout(false);
            this.PanelLogo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private DevComponents.DotNetBar.Controls.SlidePanel PanelHead;
        private DevComponents.DotNetBar.ButtonX btnAddProfessor;
        private DevComponents.DotNetBar.ButtonX btnEditProfessor;
        private DevComponents.DotNetBar.ButtonX btnEditStudent;
        private DevComponents.DotNetBar.ButtonX btnAddStudent;
        private DevComponents.DotNetBar.ButtonX btnReportCard;
        private DevComponents.DotNetBar.ButtonX btnEditLessonStudent;
        private DevComponents.DotNetBar.ButtonX btnEditLesson;
        private DevComponents.DotNetBar.ButtonX btnAddLesson;
        private DevComponents.DotNetBar.Controls.SlidePanel PanelLogo;
    }
}